function uav_anim3D(t, X, ref_path)
figure('Color','w'); hold on; grid on; axis equal;
xlabel('X (m)'); ylabel('Y (m)'); zlabel('Z (m)');
title('3D UAV Simulation');
view(45,25);
xlim([-2 2]); ylim([-2 2]); zlim([0 2]);

plot3(ref_path(:,1), ref_path(:,2), ref_path(:,3), 'r--', 'LineWidth',1.5);

L = 0.25;  % arm length

for k = 1:5:length(t)
    pos = X(k,1:3)';
    phi = X(k,7); th = X(k,8); psi = X(k,9);
    R = rotz(psi)*roty(th)*rotx(phi);

    % Each arm has two endpoints in body frame
    armX_body = [ L  0  0;
                 -L  0  0];
    armY_body = [ 0  L  0;
                  0 -L  0];

    % Transform to inertial frame
    armX = (R * armX_body')' + pos';
    armY = (R * armY_body')' + pos';

    % Clear and draw
    cla; hold on; grid on; axis equal;
    plot3(ref_path(:,1), ref_path(:,2), ref_path(:,3), 'b--', 'LineWidth',1.5);

    % Draw arms
    plot3(armX(:,1), armX(:,2), armX(:,3), 'r', 'LineWidth',3);
    plot3(armY(:,1), armY(:,2), armY(:,3), 'b', 'LineWidth',3);

    % Draw center
    plot3(pos(1), pos(2), pos(3), 'ko', 'MarkerFaceColor','k');

    xlim([-2 2]); ylim([-2 2]); zlim([0 2]);
    title(sprintf('t = %.2f s', t(k)));
    drawnow;
end
end

function R = rotx(a), R=[1 0 0;0 cos(a) -sin(a);0 sin(a) cos(a)]; end
function R = roty(a), R=[cos(a) 0 sin(a);0 1 0;-sin(a) 0 cos(a)]; end
function R = rotz(a), R=[cos(a) -sin(a) 0;sin(a) cos(a) 0;0 0 1]; end

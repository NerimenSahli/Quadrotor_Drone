% --- Configuration ---
port = "COM4";
baudRate = 115200;
dt = 0.01;      % 10ms loop matches your usleep(10000)
Kp = 0.5;       % Proportional Gain
Kd = 0.1;       % Derivative Gain

% --- Setup Serial ---
if ~isempty(serialportlist("available"))
    s = serialport(port, baudRate);
    configureTerminator(s, "LF");
    flush(s);
else
    error("Port %s not found! Close SDK Terminal first.", port);
end

% --- Create 3D Drone Model Geometry ---
fig = figure('Name', 'Drone Hardware-in-the-Loop Sim', 'Color', 'k');
ax = axes('Projection', 'perspective', 'Color', [0.1 0.1 0.1], 'XColor', 'w', 'YColor', 'w', 'ZColor', 'w');
hold on; grid on; axis equal; view(3);
xlim([-10 10]); ylim([-10 10]); zlim([0 10]);

% Create basic cylinders for the cross-arms
[X_cyl, Y_cyl, Z_cyl] = cylinder([0.1, 0.1], 10);
Z_cyl = (Z_cyl - 0.5) * 4; % Scale arm length to 4 units

% Surface objects (Initial position at origin)
h1 = surf(Z_cyl, Y_cyl, X_cyl, 'FaceColor', 'cyan', 'EdgeColor', 'none');   
h2 = surf(Y_cyl, Z_cyl, X_cyl, 'FaceColor', 'magenta', 'EdgeColor', 'none');

% --- Simulation & Physics Variables ---
targetRoll = 0;    % Level flight target
prevErrorRoll = 0;
dronePos = [0; 0; 5];  % Start at 5 units altitude
droneVel = [0; 0; 0];  % Initial velocity

fprintf('Reading Hardware... Tilt your MPU6050 to move the drone.\n');

% --- Main Loop ---
while ishandle(fig)
    dataLine = readline(s);
    if ~isempty(dataLine)
        nums = str2double(split(dataLine, ','));
        if length(nums) == 2
            currRoll = nums(1);
            currPitch = nums(2);
            
            % 1. PD CONTROL LOGIC (Monitor only)
            errorRoll = targetRoll - currRoll;
            derivRoll = (errorRoll - prevErrorRoll) / dt;
            pdOutput  = (Kp * errorRoll) + (Kd * derivRoll);
            prevErrorRoll = errorRoll;
            
            % 2. PHYSICS ENGINE (Calculate Displacement)
            % Acceleration (m/s^2) = g * tan(angle)
            accelX = 9.81 * tand(currRoll);
            accelY = 9.81 * tand(currPitch);
            
            % Integrate Acceleration to Velocity
            droneVel(1) = droneVel(1) + (accelX * dt);
            droneVel(2) = droneVel(2) - (accelY * dt); % Pitch Y is usually inverted
            
            % Integrate Velocity to Position
            dronePos(1) = dronePos(1) + (droneVel(1) * dt);
            dronePos(2) = dronePos(2) + (droneVel(2) * dt);
            
            % 3. ROTATION MATRICES
            r = deg2rad(currRoll);
            p = deg2rad(currPitch);
            y = 0; % Yaw
            
            Rx = [1, 0, 0; 0, cos(r), -sin(r); 0, sin(r), cos(r)];
            Ry = [cos(p), 0, sin(p); 0, 1, 0; -sin(p), 0, cos(p)];
            Rz = [cos(y), -sin(y), 0; sin(y), cos(y), 0; 0, 0, 1];
            R = Rz * Ry * Rx;
            
            % 4. TRANSFORM VERTICES (Rotate then Translate)
            % Transform Arm 1 (Cyan)
            v1 = [Z_cyl(:)'; Y_cyl(:)'; X_cyl(:)']; % Original coords
            rv1 = R * v1;                           % Rotate
            tv1(1,:) = rv1(1,:) + dronePos(1);      % Move X
            tv1(2,:) = rv1(2,:) + dronePos(2);      % Move Y
            tv1(3,:) = rv1(3,:) + dronePos(3);      % Move Z
            
            % Transform Arm 2 (Magenta)
            v2 = [Y_cyl(:)'; Z_cyl(:)'; X_cyl(:)'];
            rv2 = R * v2;
            tv2(1,:) = rv2(1,:) + dronePos(1);
            tv2(2,:) = rv2(2,:) + dronePos(2);
            tv2(3,:) = rv2(3,:) + dronePos(3);
            
            % 5. UPDATE PLOTS
            set(h1, 'XData', reshape(tv1(1,:), size(Z_cyl)), ...
                    'YData', reshape(tv1(2,:), size(Y_cyl)), ...
                    'ZData', reshape(tv1(3,:), size(X_cyl)));
            
            set(h2, 'XData', reshape(tv2(1,:), size(Y_cyl)), ...
                    'YData', reshape(tv2(2,:), size(Z_cyl)), ...
                    'ZData', reshape(tv2(3,:), size(X_cyl)));
            
            % Update Title with Live Info
            title(sprintf('Pos X: %.1f Y: %.1f | Roll: %.1f° | PD: %.2f', ...
                  dronePos(1), dronePos(2), currRoll, pdOutput), 'Color', 'w');
            
            % Optional: Keep camera centered on drone
            % camtarget([dronePos(1), dronePos(2), dronePos(3)]);
            
            drawnow limitrate;
        end
    end
end
clear s;
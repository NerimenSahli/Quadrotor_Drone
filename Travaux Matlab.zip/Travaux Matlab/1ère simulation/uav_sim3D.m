%% UAV 3D Simulation (Quadrotor)
clear; close all; clc;

% === Physical parameters ===
m = 1.2;                % mass (kg)
g = 9.81;               % gravity (m/s^2)
I = diag([0.02 0.02 0.04]);   % inertia matrix (kg.m^2)
invI = inv(I);

% === Controller gains ===
Kp_pos = [1.2; 1.2; 5.0]; % if changed, interesting observations 
Kd_pos = [1.6; 1.6; 3.0]; % same goes here and for every variable
Kp_att = [6; 6; 2.0];
Kd_att = [0.9; 0.9; 0.5];

% === Reference trajectory (3D) ===

ref_time = [0 3 6 9 12];
ref_path = [0 0 0;
             0 0 1;
             1 1 1.2;
             0 -1 1;
             0 0 1];
ref.posFcn = @(t) interp1(ref_time, ref_path, min(t,ref_time(end)));

ref.yaw = 0; % keep yaw = 0

% === Pack parameters ===
params.m = m; params.g = g; params.I = I; params.invI = invI;
params.Kp_pos = Kp_pos; params.Kd_pos = Kd_pos;
params.Kp_att = Kp_att; params.Kd_att = Kd_att;
params.ref = ref;

% === Simulation ===
x0 = zeros(12,1); % [x y z vx vy vz phi theta psi p q r]
tspan = [0 12];
opts = odeset('RelTol',1e-6,'AbsTol',1e-6);
[t,X] = ode45(@(t,x) uav_eom3D(t,x,params), tspan, x0, opts);

% === Animation ===
uav_anim3D(t, X, ref_path);
% === Plots for attitude and altitude ===
figure('Name','UAV states','Color','w');
subplot(4,1,1);
plot(t, X(:,3), 'LineWidth',1.5);
ylabel('z (m)'); grid on; title('Altitude');

subplot(4,1,2);
plot(t, rad2deg(X(:,7)), 'LineWidth',1.5);
ylabel('\phi (deg)'); grid on; title('Roll angle');

subplot(4,1,3);
plot(t, rad2deg(X(:,8)), 'LineWidth',1.5);
ylabel('\theta (deg)'); grid on; title('Pitch angle');

subplot(4,1,4);
plot(t, rad2deg(X(:,9)), 'LineWidth',1.5);
ylabel('\psi (deg)'); xlabel('Time (s)'); grid on; title('Yaw angle');
% Horizontal position
figure('Name','Position 3D','Color','w');
plot3(X(:,1), X(:,2), X(:,3), 'b', 'LineWidth',1.5);
hold on; plot3(ref_path(:,1), ref_path(:,2), ref_path(:,3), 'r--');
xlabel('X'); ylabel('Y'); zlabel('Z'); grid on; axis equal;
title('3D trajectory: actual vs reference');
legend('Actual','Reference');

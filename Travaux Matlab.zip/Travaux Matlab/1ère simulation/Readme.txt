Ouvrir les 3 fichiers sur Matlab.
Exécuter le uav_sim3D.m via la commande ( ou le bouton ) run.
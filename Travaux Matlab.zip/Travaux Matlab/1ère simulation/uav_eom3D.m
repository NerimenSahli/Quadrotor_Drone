function dx = uav_eom3D(t, x, P)
% 12-state model: [x y z vx vy vz phi theta psi p q r]
m = P.m; g = P.g; I = P.I; invI = P.invI;
ref = P.ref;

pos = x(1:3); v = x(4:6);
phi = x(7); th = x(8); psi = x(9);
omega = x(10:12);

% === Desired position ===
ref_pos = ref.posFcn(t)';
e_pos = ref_pos - pos;
e_vel = -v;
acc_des = P.Kp_pos .* e_pos + P.Kd_pos .* e_vel;

% === Desired thrust & attitude ===
T_des = m*(g + acc_des(3));
phi_des = (1/g)*(acc_des(1)*sin(psi) - acc_des(2)*cos(psi));
th_des  = (1/g)*(acc_des(1)*cos(psi) + acc_des(2)*sin(psi));

% === Attitude control (PD) ===
e_att = [phi_des - phi; th_des - th; ref.yaw - psi];
e_omega = -omega;
tau = P.Kp_att .* e_att + P.Kd_att .* e_omega;

% === Dynamics ===
R = rotz(psi)*roty(th)*rotx(phi);

F_inertial = R*[0;0;T_des] - m*g*[0;0;1];
acc = F_inertial / m;
omega_dot = invI * (tau - cross(omega, I*omega));

E = [1, sin(phi)*tan(th), cos(phi)*tan(th);
     0, cos(phi),        -sin(phi);
     0, sin(phi)/cos(th), cos(phi)/cos(th)];
euler_dot = E * omega;

dx = zeros(12,1);
dx(1:3) = v;
dx(4:6) = acc;
dx(7:9) = euler_dot;
dx(10:12) = omega_dot;
end

% === Rotation helpers ===
function R = rotx(a), R=[1 0 0;0 cos(a) -sin(a);0 sin(a) cos(a)]; end
function R = roty(a), R=[cos(a) 0 sin(a);0 1 0;-sin(a) 0 cos(a)]; end
function R = rotz(a), R=[cos(a) -sin(a) 0;sin(a) cos(a) 0;0 0 1]; end

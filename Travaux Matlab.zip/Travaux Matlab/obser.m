%% Question 4 : Commande par Retour d'État Pur
clear; clc; close all;

% --- Paramètres du système (Matrices de ton rapport) ---
A = [0.9046 0; 1 0]; 
B = [1; 0]; 
C = [0.4656 0.0114];
Te = 2;
t = 0:Te:100;
Pc = ones(size(t)); % Consigne échelon unitaire

% --- Calcul des Gains (Question 3) ---
poles_desires = [-0.8, -0.8];
F = acker(A, B, poles_desires);
% Calcul du gain de pré-compensation g
g = 1 / (C * inv(eye(2) - (A - B*F)) * B);

% --- Simulation ---
x = [0; 0]; % État initial nul
p = zeros(1, length(t));
u = zeros(1, length(t));

for k = 1:length(t)
    % Loi de commande
    u(k) = -F * x + g * Pc(k);
    
    % Évolution du système
    x = A * x + B * u(k);
    p(k) = C * x;
end

% --- Tracés ---
figure('Name', 'Question 4 : Retour d''Etat Pur');
subplot(2,1,1);
plot(t, p, 'b', 'LineWidth', 1.5); hold on;
plot(t, Pc, 'r--');
title('Sortie du système p(k) - Retour d''état pur');
ylabel('Pression (bar)'); grid on;
legend('Pression', 'Consigne');

subplot(2,1,2);
plot(t, u, 'g', 'LineWidth', 1.5);
title('Signal de commande u(k)');
xlabel('Temps (s)'); ylabel('Amplitude (V)'); grid on;

clear; clc; close all;

%% 1. Paramètres Physiques du Drone
m = 1.25;               % Masse totale (kg)
g = 9.81;               % Gravité (m/s^2)
L = 0.225;              % Bras de levier (m)
Ixx = 3.36e-3;          % Inertie Roulis (kg.m^2)
Iyy = 3.36e-3;          % Inertie Tangage (kg.m^2)
Izz = 6.71e-3;          % Inertie Lacet (kg.m^2)
Kf = 1.1e-5;            % Coeff de poussée (N/(rad/s)^2)
Km = 1.5e-7;            % Coeff de traînée (Nm/(rad/s)^2)
s = tf('s');
P_roll = 1 / (Ixx * s^2); 
P_pitch = 1 / (Iyy * s^2); 
wc = 15; 
opts = pidtuneOptions('DesignFocus', 'reference-tracking');
[C_roll, info] = pidtune(P_roll, 'PID', wc, opts);
pidTuner(P_roll, C_roll)
disp('--- GAINS PID THEORIQUES (Roulis / Tangage) ---');
disp(['Kp = ', num2str(C_roll.Kp)]);
disp(['Ki = ', num2str(C_roll.Ki)]);
disp(['Kd = ', num2str(C_roll.Kd)]);
disp(['Filtre N (pour le bruit du Kd) = ', num2str(C_roll.Tf)]); 
Systeme_Boucle_Fermee = feedback(C_roll * P_roll, 1);
figure('Name', 'Réponse du système (Simulation)');
step(Systeme_Boucle_Fermee);
grid on;
title('Réponse à un échelon - Axe Roulis (Pitch/Roll)');
xlabel('Temps (secondes)');
ylabel('Angle (Radians)');
stepinfo(Systeme_Boucle_Fermee)
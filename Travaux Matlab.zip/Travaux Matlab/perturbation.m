%% III. Régulateur Numérique de type PI (Simulation Complète)
clear; clc; close all;

% --- 1. Paramètres du système (issus de ton rapport) ---
Te = 2;              % Période d'échantillonnage
t = 0:Te:1000;        % Vecteur temps
N = length(t);
Pc = ones(1, N);     % Consigne (échelon unitaire)

% Coefficients de la fonction de transfert H(z) identifiés (Question 1)
a1 = 0.4656; 
a2 = 0.0114; 
b1 = 0.9046;

% Paramètres du régulateur PI choisis (Question 3)
c0 = 1.8; 
c1 = -1.3;

% --- 2. Initialisation des vecteurs de stockage ---
% Cas 1 : Sans perturbation (v = 0)
p_sans = zeros(1, N);
u_sans = zeros(1, N);
e_sans = zeros(1, N);

% Cas 2 : Avec perturbation (v = 0.1)
p_avec = zeros(1, N);
u_avec = zeros(1, N);
e_avec = zeros(1, N);
v = zeros(1, N);
v(t >= 40) = 0.1;    % La perturbation apparaît à t = 40s

% --- 3. Boucle de Simulation ---
for k = 3:N
    % --- CAS SANS PERTURBATION ---
    e_sans(k) = Pc(k) - p_sans(k-1);
    % Loi de commande PI : u(k) = u(k-1) + c0*e(k) + c1*e(k-1)
    u_sans(k) = u_sans(k-1) + c0*e_sans(k) + c1*e_sans(k-1);
    % Équation récurrente du système : p(k) = b1*p(k-1) + a1*u(k-1) + a2*u(k-2)
    p_sans(k) = b1*p_sans(k-1) + a1*u_sans(k-1) + a2*u_sans(k-2);

    % --- CAS AVEC PERTURBATION ---
    e_avec(k) = Pc(k) - p_avec(k-1);
    u_avec(k) = u_avec(k-1) + c0*e_avec(k) + c1*e_avec(k-1);
    % La perturbation v s'ajoute au signal de commande u
    u_total = u_avec(k-1) + v(k-1); 
    p_avec(k) = b1*p_avec(k-1) + a1*u_total + a2*u_avec(k-2);
end

% --- 4. Affichage des résultats ---
figure('Name', 'Comparaison PI Numérique', 'Position', [100, 100, 800, 600]);

% Subplot 1 : Sorties (Pression)
subplot(2,1,1);
plot(t, Pc, 'r--', 'LineWidth', 1); hold on;
plot(t, p_sans, 'b', 'LineWidth', 1.5);
plot(t, p_avec, 'g', 'LineWidth', 1.5);
grid on;
title('Sortie du système p(k) (Pression)');
ylabel('Pression (bar)');
legend('Consigne', 'Sans Perturbation (v=0)', 'Avec Perturbation (v=0.1)');

% Subplot 2 : Commande (u)
subplot(2,1,2);
plot(t, u_sans, 'b', 'LineWidth', 1.5); hold on;
plot(t, u_avec, 'g', 'LineWidth', 1.5);
grid on;
title('Signal de commande u(k)');
ylabel('Amplitude (V)');
xlabel('Temps (s)');
legend('u sans v', 'u avec v');

fprintf('Simulation terminée. Vérifiez les graphiques.\n');
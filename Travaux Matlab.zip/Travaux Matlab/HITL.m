% --- Configuration ---
port = "COM4"; 
baudrate = 115200;

% --- PID Gains ---
Kp = 0.5; Ki = 0.1; Kd = 0.05; 
integral_error = 0; last_error = 0; dt = 0.01;

% --- Setup Serial ---
device = serialport(port, baudrate);
configureTerminator(device, "CR/LF");
flush(device); % Clear potential garbage in the buffer

% --- Setup Figure ---
fig = figure('Name', 'HITL Monitor & Tuner', 'Color', 'w', 'Position', [100 100 1000 450]);

% 3D Subplot
ax3d = subplot(1,2,1); view(3); axis equal; grid on; hold on;
zlim([-1 1]); xlim([-1 1]); ylim([-1 1]);
xlabel('X'); ylabel('Y'); zlabel('Z');
arm_h = plot3([1 -1 0 0],[0 0 1 -1],[0 0 0 0], 'b', 'LineWidth', 5);

% Tuning Subplot
axScope = subplot(1,2,2); grid on; hold on;
hError = animatedline('Color', 'r', 'LineWidth', 1.5, 'DisplayName', 'Angle (rad)');
hCmd   = animatedline('Color', 'g', 'LineWidth', 1.5, 'DisplayName', 'PID Correction');
legend; ylim([-1.5 1.5]);

count = 0;
while ishandle(fig)
    % Only process if a full 12-byte packet is waiting
    if device.NumBytesAvailable >= 12
        raw_data = read(device, 3, "single");
        
        % --- SAFETY CHECK: PROTECT ROTX ---
        % If any value is NaN or Inf, skip this frame to prevent crashing
        if any(~isfinite(raw_data))
            flush(device); % Clear buffer to resync
            continue; 
        end
        
        roll = raw_data(1);
        
        % --- PID CORRECTION ---
        error = 0 - roll;
        integral_error = integral_error + (error * dt);
        derivative = (error - last_error) / dt;
        correction = (Kp * error) + (Ki * integral_error) + (Kd * derivative);
        correction = max(min(correction, 1), -1); % Clamping
        last_error = error;

        % --- UPDATE 3D VISUALS ---
        try
            % Apply rotation
            R = rotx(rad2deg(roll)); 
            pts = R * [1 -1 0 0; 0 0 1 -1; 0 0 0 0];
            set(arm_h, 'XData', pts(1,:), 'YData', pts(2,:), 'ZData', pts(3,:));
            
            % Update Scope
            addpoints(hError, count, roll);
            addpoints(hCmd, count, correction);
            if count > 100, xlim(axScope, [count-100 count]); end
        catch
            % Catch-all to prevent script death
            continue;
        end
        
        count = count + 1;
        drawnow limitrate;
    end
end
%% Quadrotor Linear Simulation

% State vector: [u v w p q r phi theta psi]'
x = zeros(9,1);

% Simulation time
dt = 0.01;
Tend = 5;
N = round(Tend/dt);

% History storage
Xhist = zeros(9,N);

% --- A matrix (linear dynamics) ---
A = [ ...
    %   u       v       w       p       q       r     phi   theta   psi
    -0.0429     0       0       0       0       0      0    -9.81    0;   % X_u, gravity
     0      -0.0429     0       0       0       0     9.81   0       0;   % Y_v, phi coupling
     0        0      -0.5       0       0       0      0     0       0;   % Z_w
     0     -0.4376     0     -0.8       0       0      0     0       0;   % L_v, L_p
     0.5241   0        0       0     -0.8       0      0     0       0;   % M_u, M_q
     0        0        0       0       0    -0.5231    0     0       0;   % N_r
     0        0        0       1       0       0      0     0       0;   % phi_dot = p
     0        0        0       0       1       0      0     0       0;   % theta_dot = q
     0        0        0       0       0       1      0     0       0 ]; % psi_dot = r

% --- B matrix (control inputs) ---
B = [ ...
    0      0       0.2269     0;
    0     -0.2016  0          0;
   -0.7414 0       0          0;
    0      0.7066  0          0;
    0      0       0.6662     0;
    0      0       0          0.1306;
    0      0       0          0;
    0      0       0          0;
    0      0       0          0 ];

% Step input: thrust only
u_cmd = [1; 0; 0; 0];

% Simulation loop
for k = 1:N
    dx = A*x + B*u_cmd;
    x = x + dt*dx;
    Xhist(:,k) = x;
end

% Time vector
t = 0:dt:Tend-dt;

% Plot angles
figure; plot(t, Xhist(7,:), 'LineWidth',2); hold on;
plot(t, Xhist(8,:), 'LineWidth',2);
plot(t, Xhist(9,:), 'LineWidth',2);
legend('\phi (roll)', '\theta (pitch)', '\psi (yaw)');
xlabel('Time (s)'); ylabel('Angle (rad)');
title('Quadrotor Attitude Response');
%% Question 6 : Commande avec Observateur de Luenberger
clear; clc; close all;

% --- Matrices du système ---
A = [0.9046 0; 1 0]; 
B = [1; 0]; 
C = [0.4656 0.0114];
Te = 2;
t = 0:Te:100;
Pc = ones(size(t));

% --- Gains ---
F = acker(A, B, [-0.8, -0.8]); % Gain de commande
g = 1 / (C * inv(eye(2) - (A - B*F)) * B);
L = acker(A', C', [-0.4, -0.4])'; % Gain de l'observateur (pôles plus rapides)

% --- Initialisation ---
x = [0; 0];      % État réel (inconnu en pratique)
x_hat = [0.1; 0]; % État estimé (on met un petit écart initial pour voir la convergence)

p_hist = zeros(1, length(t));
u_hist = zeros(1, length(t));
x1_reel = zeros(1, length(t));
x1_estime = zeros(1, length(t));

% --- Boucle de Simulation ---
for k = 1:length(t)
    % Loi de commande utilisant l'état ESTIMÉ
    u = -F * x_hat + g * Pc(k);
    
    % Système Réel
    y = C * x; % Seule la sortie y est mesurable
    x_next = A * x + B * u;
    
    % Observateur (Reconstruction de l'état)
    x_hat_next = A * x_hat + B * u + L * (y - C * x_hat);
    
    % Stockage pour les graphiques
    p_hist(k) = y;
    u_hist(k) = u;
    x1_reel(k) = x(1);
    x1_estime(k) = x_hat(1);
    
    % Mise à jour
    x = x_next;
    x_hat = x_hat_next;
end

% --- Tracés ---
figure('Name', 'Question 6 : Commande avec Observateur');

subplot(2,1,1);
plot(t, p_hist, 'b', 'LineWidth', 1.5); hold on;
plot(t, Pc, 'r--');
title('Sortie du système p(k) via Observateur');
ylabel('Pression'); grid on;

subplot(2,1,2);
plot(t, x1_reel, 'b', 'LineWidth', 1.2); hold on;
plot(t, x1_estime, 'r--', 'LineWidth', 1.2);
title('Convergence de l''observateur : État x1 réel vs estimé');
xlabel('Temps (s)'); ylabel('Amplitude');
legend('x1 réel', 'x1 estimé'); grid on;
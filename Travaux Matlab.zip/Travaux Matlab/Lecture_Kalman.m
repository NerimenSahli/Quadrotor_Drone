% --- Configuration ---
port = "COM4";
baudRate = 115200;

% --- Setup Serial ---
if ~isempty(serialportlist("available"))
    s = serialport(port, baudRate);
    configureTerminator(s, "LF");
    flush(s);
else
    error("Port %s not found!", port);
end

% --- Create 3D Drone Model (A simple cross shape) ---
fig = figure('Name', '3D Drone Orientation', 'Color', 'k');
ax = axes('Projection', 'perspective', 'Color', 'k');
hold on; grid on; axis equal;
view(3); % 3D View
xlim([-2 2]); ylim([-2 2]); zlim([-2 2]);
xlabel('X'); ylabel('Y'); zlabel('Z');

% Define vertices for two arms of the drone
[X1, Y1, Z1] = cylinder([0.1, 0.1], 10); % Arm 1
[X2, Y2, Z2] = cylinder([0.1, 0.1], 10); % Arm 2
Z1 = (Z1 - 0.5) * 4; % Stretch and center
Z2 = (Z2 - 0.5) * 4;

% Create surface objects
h1 = surf(Z1, Y1, X1, 'FaceColor', 'cyan', 'EdgeColor', 'none');   % Front-Back Arm
h2 = surf(Y2, Z2, X2, 'FaceColor', 'magenta', 'EdgeColor', 'none'); % Left-Right Arm
title('Live Drone Attitude', 'Color', 'w');

% --- Real-time Animation Loop ---
while ishandle(fig)
    dataLine = readline(s);
    if ~isempty(dataLine)
        nums = str2double(split(dataLine, ','));
        if length(nums) == 2
            % Convert degrees to radians for math
            roll = deg2rad(nums(1));   % Angle around X
            pitch = deg2rad(nums(2));  % Angle around Y
            yaw = 0;                   % We don't have Yaw yet
            
            % 1. Define Rotation Matrices
            Rx = [1, 0, 0; 0, cos(roll), -sin(roll); 0, sin(roll), cos(roll)];
            Ry = [cos(pitch), 0, sin(pitch); 0, 1, 0; -sin(pitch), 0, cos(pitch)];
            Rz = [cos(yaw), -sin(yaw), 0; sin(yaw), cos(yaw), 0; 0, 0, 1];
            
            % Combined Rotation Matrix (R = Z * Y * X)
            R = Rz * Ry * Rx;
            
            % 2. Update Arm 1 Coordinates
            orig_coords1 = [Z1(:)'; Y1(:)'; X1(:)'];
            new_coords1 = R * orig_coords1;
            set(h1, 'XData', reshape(new_coords1(1,:), size(Z1)), ...
                    'YData', reshape(new_coords1(2,:), size(Y1)), ...
                    'ZData', reshape(new_coords1(3,:), size(X1)));
            
            % 3. Update Arm 2 Coordinates
            orig_coords2 = [Y2(:)'; Z2(:)'; X2(:)'];
            new_coords2 = R * orig_coords2;
            set(h2, 'XData', reshape(new_coords2(1,:), size(Y2)), ...
                    'YData', reshape(new_coords2(2,:), size(Z2)), ...
                    'ZData', reshape(new_coords2(3,:), size(X2)));
            
            drawnow limitrate;
        end
    end
end
clear s;
## ##########################################################################
## Zybo Z7-20 / Z7-10 Constraints
## ##########################################################################

# Horloge SCL
set_property PACKAGE_PIN V15 [get_ports IIC_0_scl_io]
set_property IOSTANDARD LVCMOS33 [get_ports IIC_0_scl_io]
set_property PULLUP true [get_ports IIC_0_scl_io]

# Donn�es SDA
set_property PACKAGE_PIN W15 [get_ports IIC_0_sda_io]
set_property IOSTANDARD LVCMOS33 [get_ports IIC_0_sda_io]
set_property PULLUP true [get_ports IIC_0_sda_io]

## === MPU6050 Interrupt (Connecteur JB - Pin 3) ===
## Si tu utilises l'interruption, elle arrive sur le signal T19.
set_property -dict {PACKAGE_PIN T11 IOSTANDARD LVCMOS33} [get_ports {mpu6050_int[0]}]


# Configuration pour le connecteur JE (Pmod)
set_property -dict {PACKAGE_PIN T14 IOSTANDARD LVCMOS33} [get_ports mot_a]
set_property -dict {PACKAGE_PIN T15 IOSTANDARD LVCMOS33} [get_ports mot_b]
set_property -dict {PACKAGE_PIN P14 IOSTANDARD LVCMOS33} [get_ports mot_c]
set_property -dict {PACKAGE_PIN R14 IOSTANDARD LVCMOS33} [get_ports mot_d]

set_property PACKAGE_PIN N15 [get_ports uart_rtl_rxd]
set_property PACKAGE_PIN L14 [get_ports uart_rtl_txd]
set_property IOSTANDARD LVCMOS33 [get_ports uart_rtl_rxd]
set_property IOSTANDARD LVCMOS33 [get_ports uart_rtl_txd]
